 
package proyectochespirito;
 
public class ProyectoChespirito {

   
    public static void main(String[] args) {
        
        Conexion miconexion = new Conexion();
        miconexion.Conectar();
     }
    
}
